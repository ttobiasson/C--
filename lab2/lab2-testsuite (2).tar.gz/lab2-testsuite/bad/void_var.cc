int main() {
  void x;

  return 0;
}
