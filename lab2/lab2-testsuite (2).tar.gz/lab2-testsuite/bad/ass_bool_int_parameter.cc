int main() {
     int i = foo(true);
     return 0 ;
}

int foo(bool b) { b = 1; }
