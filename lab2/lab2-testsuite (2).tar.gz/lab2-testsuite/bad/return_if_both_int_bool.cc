int main() {
        if (true)
                return false;
	else
		return true;
        return 1;
}
