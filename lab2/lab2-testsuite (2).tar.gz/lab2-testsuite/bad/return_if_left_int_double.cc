// Return must always return something of the right type.
int main() {
  if (42 >= 0) {
    return 0.5;
  } else {}

  return 0;
}
