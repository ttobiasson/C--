int main () {
  return false / 345;
}