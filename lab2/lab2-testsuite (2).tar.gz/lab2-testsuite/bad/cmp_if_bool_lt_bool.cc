int main () {
	if (false < true) { } else { }
	return 0;
}
