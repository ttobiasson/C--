int abc(bool b, int d) {
  return 0;
}

int main() {
  return abc(true, 0);
}
