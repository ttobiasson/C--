/* Test arithmetic and comparisons */

int main() {
    int x = 56;
    int y = 23;
    printInt(x+y);
    printInt(x-y);
    printInt(x*y);
    printInt(45/2);
    return 0;
}
