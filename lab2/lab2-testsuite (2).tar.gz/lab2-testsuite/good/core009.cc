// Calling functions which take zero parameters

int foo() {
 return 10;
}

int main() {
 int x = foo();
 printInt(x);
 return 0 ;
}
