int f(int y) {
  return --y;
}
int main() {
  printInt(f(0));
  return 0;
}
